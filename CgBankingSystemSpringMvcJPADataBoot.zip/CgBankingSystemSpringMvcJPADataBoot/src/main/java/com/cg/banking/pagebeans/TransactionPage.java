package com.cg.banking.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TransactionPage {
	@FindBy(how = How.CLASS_NAME, name = "accountNumber")
	private WebElement accountNumber;
	@FindBy(how=How.CLASS_NAME,name="pinNumber")
	private WebElement pinNumber;
	@FindBy(how = How.CLASS_NAME, name = "submit")
	private WebElement button;
	@FindBy(how=How.ID, id="exception")
	private WebElement exception;
	
	public TransactionPage() {}
	
	public void setAccountNumber(String accountNumber) {
		this.accountNumber.clear();
		this.accountNumber.sendKeys(accountNumber);
	}
	public void setPinNumber(String pinNumber) {
		this.pinNumber.clear();
		this.pinNumber.sendKeys(pinNumber);
	}
	public String getException() {
		return this.exception.getText();
	}
	public void clickSubmit() {
		this.button.click();
	}
	
}
