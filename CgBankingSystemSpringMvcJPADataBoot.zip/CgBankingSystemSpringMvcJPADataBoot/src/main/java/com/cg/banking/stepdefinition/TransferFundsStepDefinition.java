package com.cg.banking.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransferFundsStepDefinition {
	@Given("^User is on Banking Services fundsTransfer page$")
	public void user_is_on_Banking_Services_fundsTransfer_page() throws Throwable {

	}

	@When("^User entered the correct AccountNofrom and pinNo$")
	public void user_entered_the_correct_AccountNofrom_and_pinNo() throws Throwable {

	}

	@When("^User entered the correct AccountNoTo$")
	public void user_entered_the_correct_AccountNoTo() throws Throwable {

	}

	@When("^User entered the amount to be transferred$")
	public void user_entered_the_amount_to_be_transferred() throws Throwable {

	}

	@Then("^Money will be Transferred into accountTo$")
	public void money_will_be_Transferred_into_accountTo() throws Throwable {

	}

	@When("^User entered the incorrect AccountNoTo$")
	public void user_entered_the_incorrect_AccountNoTo() throws Throwable {

	}

	@Then("^Money will not be Transferred into accountTo$")
	public void money_will_not_be_Transferred_into_accountTo() throws Throwable {

	}

	@Then("^page will be redirected to fundsTransfer page$")
	public void page_will_be_redirected_to_fundsTransfer_page() throws Throwable {

	}

	@When("^User entered the amount to be transferred more than available amount$")
	public void user_entered_the_amount_to_be_transferred_more_than_available_amount() throws Throwable {

	}

	@When("^User entered the amount to be transferred less than (\\d+)$")
	public void user_entered_the_amount_to_be_transferred_less_than(int arg1) throws Throwable {

	}

	@When("^User entered the incorrect AccountNofrom$")
	public void user_entered_the_incorrect_AccountNofrom() throws Throwable {

	}

	@When("^User entered the correct pinNo$")
	public void user_entered_the_correct_pinNo() throws Throwable {

	}

	@When("^User entered the correct AccountNofrom$")
	public void user_entered_the_correct_AccountNofrom() throws Throwable {

	}

	@When("^User entered the incorrect pinNo$")
	public void user_entered_the_incorrect_pinNo() throws Throwable {

	}

}
