package com.cg.banking.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.banking.pagebeans.DepositPage;
import com.cg.banking.pagebeans.WithdrawPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WithdrawMoneyStepDefinition {
	private WebDriver driver;
	private WithdrawPage withdrawPage;
	
	@Given("^User is on Banking Services withdraw page$")
	public void user_is_on_Banking_Services_withdraw_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:4444/withdraw");
		withdrawPage=PageFactory.initElements(driver,WithdrawPage.class);
	}

	@When("^User entered the correct AccountNo for withdrawing money$")
	public void user_entered_the_correct_AccountNo_for_withdrawing_money() throws Throwable {
		withdrawPage.setAccountNumber("123123123");
	}

	@When("^User entered correct pin number for withdrawing money$")
	public void user_entered_correct_pin_number_for_withdrawing_money() throws Throwable {
		withdrawPage.setPinNumber("1234");
	}

	@When("^User entered the amount to be withdrawn$")
	public void user_entered_the_amount_to_be_withdrawn() throws Throwable {
		withdrawPage.setAmount("1");
		withdrawPage.clickSubmit();
	}

	@Then("^Money will be withdrawn from account and withdraw success page is displayed$")
	public void money_will_be_withdrawn_from_account_and_withdraw_success_page_is_displayed() throws Throwable {
		String expectedTitle = "Withdrawal Successful";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User entered the amount to be withdrawn more than balance$")
	public void user_entered_the_amount_to_be_withdrawn_more_than_balance() throws Throwable {
		withdrawPage.setAmount("999999999");
		withdrawPage.clickSubmit();
	}

	@Then("^Money will not be withdrawn from account and redirect to withdraw page$")
	public void money_will_not_be_withdrawn_from_account_and_redirect_to_withdraw_page() throws Throwable {
		String expectedError = "Insufficient Balance in account";
		String actualError = withdrawPage.getException();
		Assert.assertEquals(expectedError, actualError);
		driver.close();
	}

	@When("^User entered incorrect pin number for withdrawing money$")
	public void user_entered_incorrect_pin_number_for_withdrawing_money() throws Throwable {
		withdrawPage.setPinNumber("4567");
	}
	@Then("^Money will not be withdrawn from account and redirect to withdraw page with invalid pin number exception$")
	public void money_will_not_be_withdrawn_from_account_and_redirect_to_withdraw_page_with_invalid_pin_number_exception() throws Throwable {
		String expectedError = "Invalid Pin Number";
		String actualError = withdrawPage.getException();
		Assert.assertEquals(expectedError, actualError);
		driver.close();
	}
}
