package com.cg.banking.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.banking.pagebeans.TransactionPage;
import com.cg.banking.pagebeans.WithdrawPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransactionStepDefinition {
	private WebDriver driver;
	private TransactionPage page;
	@Given("^User is on get Transaction Details Page$")
	public void user_is_on_get_Transaction_Details_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:4444/transaction");
		page=PageFactory.initElements(driver,TransactionPage.class);
	}

	@When("^User entered the correct Account details$")
	public void user_entered_the_correct_Account_details() throws Throwable {
		page.setAccountNumber("123123123");
		page.setPinNumber("1234");
		page.clickSubmit();
	}
	@Then("^Details are retrieved from the database and shown on success page$")
	public void details_are_retrieved_from_the_database_and_shown_on_success_page() throws Throwable {
		String expectedTitle = "Transaction Details";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	@When("^User entered incorrect Account details$")
	public void user_entered_incorrect_Account_details() throws Throwable {
		page.setAccountNumber("123123123");
		page.setPinNumber("7894");
		page.clickSubmit();
	}

	@Then("^page is returned to getTransactionDetails page$")
	public void page_is_returned_to_getTransactionDetails_page() throws Throwable {
		String expectedError = "Invalid Pin Number";
		String actualError = page.getException();
		Assert.assertEquals(expectedError, actualError);
		driver.close();
	}
}
